/*
 * This variable is set to prevent conflict with for instance the Prototype library if also used in the project
 */
var $j = jQuery.noConflict();