/********************************************************************
 * Author: Nicolas Rod, nico@alaxos.com 
 * website: www.alaxos.com, www.alaxos.ch
 */

/********************************************************************
 * Global constants 
 */
l_a="aa";
l_b="bb";
l_c="cc";
l_d="dd";
l_e="ee";
l_f="ff";
l_g="gg";
l_h="hh";
l_i="ii";
l_j="jj";
l_k="kk";
l_l="ll";
l_m="mm";
l_n="nn";
l_o="oo";
l_p="pp";
l_q="qq";
l_r="rr";
l_s="ss";
l_t="tt";
l_u="uu";
l_v="vv";
l_w="ww";
l_x="xx";
l_y="yy";
l_z="zz";
l_dot="..";
l_under="__";
l_dash="--";
l_at="@@";